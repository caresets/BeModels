# Résumé des artefacts - CareSets - data models v0.1.0

## Résumé des artefacts

 
There is no translation page available for the current page, so it has been rendered in the default language 

