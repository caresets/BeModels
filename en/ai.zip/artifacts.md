# Artifacts Summary - CareSets - data models v0.1.0

## Artifacts Summary

